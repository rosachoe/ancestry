//
//  CemeteryTableViewController.swift
//  Cemetery
//
//  Created by Rosa Choe on 4/11/17.
//  Copyright © 2017 Rosa Choe. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class CemeteryTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var cemeteries = [[String:AnyObject]]()
    var cems = [Cemetery]()

    @IBOutlet weak var cemeteryTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        cemeteryTable.delegate = self
        cemeteryTable.dataSource = self
        Alamofire.request("https://www.findagrave.com/cgi-bin/api.cgi?mode=cemetery&amp;cemeteryName=mead&amp;limit=405&amp;skip=0").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let cemeteryJSON = JSON(responseData.result.value!)
                
                if let resData = cemeteryJSON["cemetery"].arrayObject {
                    self.cemeteries = resData as! [[String:AnyObject]]
                }
                if self.cemeteries.count > 0 {
                    self.cemeteryTable.reloadData()
                }
            }
        }
        initData()


        // Do any additional setup after loading the view.
    }
    
    func initData() {
        for i in 0...self.cemeteries.count-1 {
            if let cem = Cemetery.fromJSON(json: cemeteries[i]) {
                cems.append(cem)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cemeteries.count
    }
    
    //At a given index, what should the cell look like
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cemetery", for: indexPath) as! CemeteryTableViewCell
        
        var dict = cemeteries[(indexPath as NSIndexPath).row]
        cell.name?.text = dict["cemeteryName"] as? String
//        cell.textLabel?.text = dict["name"] as? String
//        cell.detailTextLabel?.text = dict["email"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! CemeteryTableViewCell
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
