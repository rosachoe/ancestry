//
//  Cemetery.swift
//  Cemetery
//
//  Created by Rosa Choe on 4/11/17.
//  Copyright © 2017 Rosa Choe. All rights reserved.
//

import Foundation
import MapKit
import SwiftyJSON

class Cemetery: NSObject, MKAnnotation {
    let title: String?
    let coordinate: CLLocationCoordinate2D
    
    init(title: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
        super.init()
    }
    
    class func fromJSON(json: [String:AnyObject]) -> Cemetery? {
        var title: String
        if let jsonTitle = json["cemeteryName"] as? String {
            title = jsonTitle
        } else {
            title = ""
        }
        
        var coordinate: CLLocationCoordinate2D
        if let lat = json["latitude"] as? Double, let lon = json["longitude"] as? Double {
            coordinate = CLLocationCoordinate2DMake(lat, lon)
            return Cemetery(title: title, coordinate: coordinate)
        }
        return nil
        
    }
    
    
}
